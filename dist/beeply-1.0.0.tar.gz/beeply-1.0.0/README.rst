``# beeply`` A python package that helps you produce musical notes using
your computer's characteristic beep sounds. Written in Python.

Dependencies
------------

``winsound`` python package is required. This package is present by
default, if you use python on windows. However, for linux users, the
package will automatically be installed along with ``beeply``.

Installation
------------

Install from Pypi using ``sudo pip install beeply``.